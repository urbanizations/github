-- Path: ReplicatedStorage_/Modules/AnimationLibrary/SoundCallbacks/katana_crystalkatana_inspect_rare (ModuleScript)
-- Size: 3406

-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 1
    if not p1:_AnimationWait(script.Name, p3, 1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.2 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.1 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.11 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.11 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 1.125 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 1.125 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.075 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14427782350", 1, 0.875, true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.55 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://118748685078128", 1, 1.5 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 2.35 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://14000023581", 1, 2 + 0.25 * math.random(), true, 10);
    p1:CreateSound("rbxassetid://118748685078128", 1, 2 + 0.25 * math.random(), true, 10);

    if not p1:_AnimationWait(script.Name, p3, 0.6 / p2) then
        return;
    end;

    p1:CreateSound("rbxassetid://134472359434980", 0.5, 1, true, 10);
end;